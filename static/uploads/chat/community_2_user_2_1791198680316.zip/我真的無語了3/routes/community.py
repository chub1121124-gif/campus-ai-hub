from flask import Blueprint, render_template, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db
from models import (
    User,
    Community,
    CommunityMember,
    CommunityJoinRequest
)
from .auth import login_required

community_bp = Blueprint(
    "community",
    __name__,
    url_prefix="/communities"
)


def current_user():
    return User.query.get(session.get("user_id"))


@community_bp.route("/")
@login_required
def community_page():
    user = current_user()

    keyword = request.args.get("q", "").strip()
    filter_type = request.args.get("filter", "all")

    query = Community.query

    if keyword:
        query = query.filter(
            db.or_(
                Community.name.contains(keyword),
                Community.description.contains(keyword)
            )
        )

    if filter_type in ["group", "club", "forum"]:
        query = query.filter_by(community_type=filter_type)

    communities = query.order_by(
        Community.created_at.desc()
    ).all()

    joined_ids = {
        member.community_id
        for member in CommunityMember.query.filter_by(
            user_id=user.id
        ).all()
    }

    return render_template(
        "communities.html",
        current_user=user,
        communities=communities,
        joined_ids=joined_ids
    )


@community_bp.route("/create", methods=["POST"])
@login_required
def create_community():
    user = current_user()

    name = request.form.get("name", "").strip()
    description = request.form.get("description", "").strip()
    community_type = request.form.get("community_type", "group")
    join_mode = request.form.get("join_mode", "open")
    password = request.form.get("password", "").strip()

    if not name:
        return jsonify({
            "success": False,
            "message": "名稱必填"
        }), 400

    if join_mode in ["password", "password_approval"] and not password:
        return jsonify({
            "success": False,
            "message": "此加入方式需要設定密碼"
        }), 400

    community = Community(
        name=name,
        description=description,
        community_type=community_type,
        join_mode=join_mode,
        join_password_hash=(
            generate_password_hash(password)
            if password else None
        ),
        creator_id=user.id
    )

    db.session.add(community)
    db.session.commit()

    db.session.add(
        CommunityMember(
            community_id=community.id,
            user_id=user.id,
            role="owner"
        )
    )
    db.session.commit()

    return jsonify({
        "success": True,
        "message": "建立成功"
    })


@community_bp.route("/<int:community_id>/join", methods=["POST"])
@login_required
def join_community(community_id):
    user = current_user()
    community = Community.query.get_or_404(community_id)

    existing = CommunityMember.query.filter_by(
        community_id=community.id,
        user_id=user.id
    ).first()

    if existing:
        return jsonify({
            "success": False,
            "message": "你已經加入"
        }), 400

    password = request.form.get("password", "").strip()

    if community.join_mode in ["password", "password_approval"]:
        if not password or not check_password_hash(
            community.join_password_hash,
            password
        ):
            return jsonify({
                "success": False,
                "message": "加入密碼錯誤"
            }), 400

    if community.join_mode in ["approval", "password_approval"]:
        old_request = CommunityJoinRequest.query.filter_by(
            community_id=community.id,
            user_id=user.id,
            status="pending"
        ).first()

        if old_request:
            return jsonify({
                "success": False,
                "message": "已送出申請"
            }), 400

        db.session.add(
            CommunityJoinRequest(
                community_id=community.id,
                user_id=user.id,
                status="pending"
            )
        )
        db.session.commit()

        return jsonify({
            "success": True,
            "message": "申請已送出"
        })

    db.session.add(
        CommunityMember(
            community_id=community.id,
            user_id=user.id,
            role="member"
        )
    )
    db.session.commit()

    return jsonify({
        "success": True,
        "message": "加入成功"
    })