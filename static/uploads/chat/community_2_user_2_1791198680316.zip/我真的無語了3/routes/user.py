from flask import Blueprint, render_template, session
from models import ChatRoom, Note, Post, User
from .auth import login_required

user_bp = Blueprint('user', __name__, url_prefix='/dashboard')

@user_bp.route('')
@login_required
def dashboard():
    current_user = User.query.get(session['user_id'])
    posts = Post.query.order_by(Post.created_at.desc()).all()
    my_posts = Post.query.filter_by(author_id=session['user_id']).order_by(Post.created_at.desc()).all()
    notes = Note.query.order_by(Note.created_at.desc()).limit(5).all()
    rooms = ChatRoom.query.order_by(ChatRoom.created_at.desc()).limit(5).all()
    return render_template(
        'dashboard.html',
        current_user=current_user,
        posts=posts,
        my_posts=my_posts,
        notes=notes,
        rooms=rooms,
    )
