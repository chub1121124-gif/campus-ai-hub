import os

from flask import (
    Flask,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for
)
from werkzeug.security import generate_password_hash
from werkzeug.utils import secure_filename

from config import Config
from extensions import cors, db, socketio

from models import (
    ChatMessage,
    ChatRoom,
    ChatRoomMember,
    Community,
    CommunityJoinRequest,
    CommunityMember,
    CommunityMessage,
    Department,
    Friendship,
    Meeting,
    MeetingParticipant,
    Note,
    NoteAttachment,
    Post,
    User
)

from routes import (
    admin_bp,
    announcement_bp,
    auth_bp,
    chat_bp,
    community_bp,
    meeting_bp,
    note_bp,
    user_bp,
    friends_bp,
)

# 載入 Socket.IO 事件
# 必須存在專案根目錄 socket_events.py
import socket_events


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # =========================================================
    # 檔案上傳設定
    # =========================================================
    app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024  # 100 MB

    app.config["UPLOAD_FOLDER"] = os.path.join(
        app.root_path,
        "static",
        "uploads"
    )

    app.config["AVATAR_UPLOAD_FOLDER"] = os.path.join(
        app.root_path,
        "static",
        "uploads",
        "avatars"
    )

    app.config["NOTE_UPLOAD_FOLDER"] = os.path.join(
        app.root_path,
        "static",
        "uploads",
        "notes"
    )

    app.config["CHAT_UPLOAD_FOLDER"] = os.path.join(
        app.root_path,
        "static",
        "uploads",
        "chat"
    )

    app.config["COMMUNITY_UPLOAD_FOLDER"] = os.path.join(
        app.root_path,
        "static",
        "uploads",
        "communities"
    )

    app.config["MEETING_UPLOAD_FOLDER"] = os.path.join(
        app.root_path,
        "static",
        "uploads",
        "meetings"
    )

    upload_folders = [
        app.config["UPLOAD_FOLDER"],
        app.config["AVATAR_UPLOAD_FOLDER"],
        app.config["NOTE_UPLOAD_FOLDER"],
        app.config["CHAT_UPLOAD_FOLDER"],
        app.config["COMMUNITY_UPLOAD_FOLDER"],
        app.config["MEETING_UPLOAD_FOLDER"]
    ]

    for folder in upload_folders:
        os.makedirs(folder, exist_ok=True)

    # =========================================================
    # 初始化擴充套件
    # =========================================================
    db.init_app(app)
    cors.init_app(
        app,
        supports_credentials=True
    )
    socketio.init_app(app)

    # =========================================================
    # 註冊 Blueprint
    # =========================================================
    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(announcement_bp)
    app.register_blueprint(note_bp)
    app.register_blueprint(chat_bp)
    app.register_blueprint(friends_bp)
    app.register_blueprint(community_bp)
    app.register_blueprint(meeting_bp)
    app.register_blueprint(admin_bp)

    # =========================================================
    # 登入首頁
    # =========================================================
    @app.route("/")
    def index():
        if "user_id" in session:
            return redirect(url_for("dashboard"))

        return render_template("login.html")

    # =========================================================
    # 主儀表板
    # =========================================================
    @app.route("/dashboard")
    def dashboard():
        current_user = get_logged_in_user()

        if not current_user:
            return redirect(url_for("index"))

        recent_posts = (
            Post.query
            .order_by(Post.created_at.desc())
            .limit(3)
            .all()
        )

        note_count = Note.query.filter_by(
            owner_id=current_user.id
        ).count()

        friend_count = Friendship.query.filter(
            Friendship.status == "accepted",
            db.or_(
                Friendship.requester_id == current_user.id,
                Friendship.addressee_id == current_user.id
            )
        ).count()

        community_count = CommunityMember.query.filter_by(
            user_id=current_user.id
        ).count()

        return render_template(
            "dashboard.html",
            current_user=current_user,
            recent_posts=recent_posts,
            note_count=note_count,
            friend_count=friend_count,
            community_count=community_count
        )

    # =========================================================
    # 個人資料頁
    # =========================================================
    @app.route("/profile")
    def profile_page():
        current_user = get_logged_in_user()

        if not current_user:
            return redirect(url_for("index"))

        departments = (
            Department.query
            .order_by(Department.name.asc())
            .all()
        )

        return render_template(
            "profile.html",
            current_user=current_user,
            user=current_user,
            departments=departments
        )

    # =========================================================
    # 智慧資訊中心
    # =========================================================
    @app.route("/announcements")
    def announcements_page():
        current_user = get_logged_in_user()

        if not current_user:
            return redirect(url_for("index"))

        posts = (
            Post.query
            .order_by(Post.created_at.desc())
            .all()
        )

        return render_template(
            "announcements.html",
            current_user=current_user,
            posts=posts
        )

    # =========================================================
    # 智慧筆記頁
    # =========================================================
    @app.route("/notes")
    def notes_page():
        current_user = get_logged_in_user()

        if not current_user:
            return redirect(url_for("index"))

        return render_template(
            "notes.html",
            current_user=current_user
        )

    # =========================================================
    # 好友管理頁
    # =========================================================
    @app.route("/friends")
    def friends_page():
        current_user = get_logged_in_user()

        if not current_user:
            return redirect(url_for("index"))

        return render_template(
            "friends.html",
            current_user=current_user
        )

    # =========================================================
    # 好友聊天室頁
    # =========================================================
    @app.route("/chat")
    def chat_page():
        current_user = get_logged_in_user()

        if not current_user:
            return redirect(url_for("index"))

        return render_template(
            "chat.html",
            current_user=current_user
        )

    # =========================================================
    # GET 登出備用網址
    # 主要登出仍可使用 auth.logout
    # =========================================================
    @app.route("/logout")
    def logout_page():
        session.clear()
        return redirect(url_for("index"))

    # =========================================================
    # 健康檢查
    # =========================================================
    @app.route("/api/health")
    def health():
        return jsonify({
            "success": True,
            "message": "Campus AI system is running"
        })

    # =========================================================
    # 取得個人資料 API
    # =========================================================
    @app.route("/api/profile", methods=["GET"])
    def get_profile():
        current_user = get_logged_in_user(clear_invalid=False)

        if not current_user:
            return jsonify({
                "success": False,
                "message": "請先登入"
            }), 401

        return jsonify({
            "success": True,
            "data": current_user.to_dict()
        })

    # =========================================================
    # 修改個人資料 API
    # =========================================================
    @app.route("/api/profile/update", methods=["POST"])
    def update_profile():
        current_user = get_logged_in_user(clear_invalid=False)

        if not current_user:
            return jsonify({
                "success": False,
                "message": "請先登入"
            }), 401

        full_name = request.form.get(
            "full_name",
            ""
        ).strip()

        email = request.form.get(
            "email",
            ""
        ).strip()

        birthday = request.form.get(
            "birthday",
            ""
        ).strip()

        student_no = request.form.get(
            "student_no",
            ""
        ).strip()

        department_id = request.form.get(
            "department_id",
            ""
        ).strip()

        grade_level = request.form.get(
            "grade_level",
            ""
        ).strip()

        interests = request.form.get(
            "interests",
            ""
        ).strip()

        bio = request.form.get(
            "bio",
            ""
        ).strip()

        if not full_name:
            return jsonify({
                "success": False,
                "message": "姓名為必填"
            }), 400

        # 檢查 Email 重複
        if email:
            existing_email_user = User.query.filter(
                User.email == email,
                User.id != current_user.id
            ).first()

            if existing_email_user:
                return jsonify({
                    "success": False,
                    "message": "Email 已被其他帳號使用"
                }), 400

        # 檢查學號重複
        if student_no:
            existing_student_user = User.query.filter(
                User.student_no == student_no,
                User.id != current_user.id
            ).first()

            if existing_student_user:
                return jsonify({
                    "success": False,
                    "message": "學號已被其他帳號使用"
                }), 400

        # 檢查科系是否存在
        selected_department_id = None

        if department_id:
            try:
                selected_department_id = int(department_id)
            except ValueError:
                return jsonify({
                    "success": False,
                    "message": "科系資料格式錯誤"
                }), 400

            department = db.session.get(
                Department,
                selected_department_id
            )

            if not department:
                return jsonify({
                    "success": False,
                    "message": "找不到指定科系"
                }), 400

        # 上傳頭像
        avatar_file = request.files.get("avatar_file")

        if avatar_file and avatar_file.filename:
            original_filename = avatar_file.filename.strip()

            if "." not in original_filename:
                return jsonify({
                    "success": False,
                    "message": "頭像檔案缺少副檔名"
                }), 400

            extension = (
                original_filename
                .rsplit(".", 1)[-1]
                .lower()
            )

            allowed_extensions = {
                "png",
                "jpg",
                "jpeg",
                "gif",
                "webp"
            }

            if extension not in allowed_extensions:
                return jsonify({
                    "success": False,
                    "message": (
                        "圖片格式只支援 "
                        "png、jpg、jpeg、gif、webp"
                    )
                }), 400

            safe_name = secure_filename(original_filename)

            if not safe_name:
                safe_name = f"avatar.{extension}"

            new_filename = (
                f"user_{current_user.id}.{extension}"
            )

            save_path = os.path.join(
                app.config["AVATAR_UPLOAD_FOLDER"],
                new_filename
            )

            # 刪除相同使用者的舊頭像
            for old_extension in allowed_extensions:
                old_path = os.path.join(
                    app.config["AVATAR_UPLOAD_FOLDER"],
                    f"user_{current_user.id}.{old_extension}"
                )

                if (
                    os.path.exists(old_path)
                    and old_path != save_path
                ):
                    try:
                        os.remove(old_path)
                    except OSError:
                        pass

            avatar_file.save(save_path)

            current_user.avatar_url = (
                f"/static/uploads/avatars/"
                f"{new_filename}"
            )

        current_user.full_name = full_name
        current_user.email = email or None
        current_user.birthday = birthday or None
        current_user.student_no = student_no or None
        current_user.department_id = selected_department_id
        current_user.grade_level = grade_level or None
        current_user.interests = interests or None
        current_user.bio = bio or None

        try:
            db.session.commit()

            session["full_name"] = current_user.full_name

            return jsonify({
                "success": True,
                "message": "個人資料已成功儲存",
                "data": current_user.to_dict()
            })

        except Exception as error:
            db.session.rollback()

            return jsonify({
                "success": False,
                "message": f"儲存失敗：{str(error)}"
            }), 500

    # =========================================================
    # 建立資料表與初始資料
    # =========================================================
    with app.app_context():
        db.create_all()
        seed_data()

    return app


def get_logged_in_user(clear_invalid=True):
    """
    取得目前登入使用者。
    若 session 無效，可選擇是否清除 session。
    """
    user_id = session.get("user_id")

    if not user_id:
        return None

    current_user = db.session.get(User, user_id)

    if not current_user and clear_invalid:
        session.clear()

    return current_user


def seed_data():
    """
    建立初始測試資料。
    只在資料不存在時加入。
    """

    # =========================================================
    # 科系
    # =========================================================
    if Department.query.count() == 0:
        db.session.add_all([
            Department(
                code="CS",
                name="資訊工程系"
            ),
            Department(
                code="MIS",
                name="資訊管理系"
            ),
            Department(
                code="EE",
                name="電機工程系"
            )
        ])

        db.session.commit()

    cs_department = Department.query.filter_by(
        code="CS"
    ).first()

    mis_department = Department.query.filter_by(
        code="MIS"
    ).first()

    # =========================================================
    # 使用者
    # =========================================================
    admin = User.query.filter_by(
        username="admin"
    ).first()

    if not admin:
        admin = User(
            full_name="系統管理員",
            username="admin",
            email="admin@example.com",
            birthday="1990-01-01",
            password_hash=generate_password_hash(
                "admin123"
            ),
            role="admin",
            student_no="A0001",
            department_id=(
                cs_department.id
                if cs_department else None
            ),
            grade_level="管理者",
            interests="系統管理、校務平台、資料維護",
            bio="我是系統管理員，負責管理貼文與使用者。",
            avatar_url=None
        )

        db.session.add(admin)
        db.session.commit()

    user = User.query.filter_by(
        username="ming"
    ).first()

    if not user:
        user = User(
            full_name="王小明",
            username="ming",
            email="ming@example.com",
            birthday="2004-05-10",
            password_hash=generate_password_hash(
                "user123"
            ),
            role="user",
            student_no="S11223344",
            department_id=(
                cs_department.id
                if cs_department else None
            ),
            grade_level="三年級",
            interests="AI、程式設計、資料分析",
            bio="我是資訊工程系學生，喜歡做網頁與 AI 專題。",
            avatar_url=None
        )

        db.session.add(user)
        db.session.commit()

    user2 = User.query.filter_by(
        username="mei"
    ).first()

    if not user2:
        user2 = User(
            full_name="陳小美",
            username="mei",
            email="mei@example.com",
            birthday="2005-03-20",
            password_hash=generate_password_hash(
                "user123"
            ),
            role="user",
            student_no="S11223345",
            department_id=(
                mis_department.id
                if mis_department else None
            ),
            grade_level="二年級",
            interests="UI 設計、企劃、資料整理",
            bio="我喜歡整理系統流程，也喜歡做介面。",
            avatar_url=None
        )

        db.session.add(user2)
        db.session.commit()

    # 重新取得，確保都有 id
    admin = User.query.filter_by(username="admin").first()
    user = User.query.filter_by(username="ming").first()
    user2 = User.query.filter_by(username="mei").first()

    # =========================================================
    # 貼文
    # =========================================================
    if Post.query.count() == 0 and admin and user:
        db.session.add_all([
            Post(
                title="期中考週圖書館延長開放",
                content=(
                    "圖書館本週延長開放到晚上 11 點，"
                    "請同學多加利用。"
                ),
                category="教務",
                is_ai_priority=True,
                author_id=admin.id
            ),
            Post(
                title="AI 專題競賽開始報名",
                content=(
                    "歡迎同學組隊參加，"
                    "系統將依興趣與科系推送。"
                ),
                category="競賽",
                is_ai_priority=True,
                author_id=admin.id
            ),
            Post(
                title="專題組員招募",
                content=(
                    "正在找前端與資料庫同學"
                    "一起完成校園 AI 專題。"
                ),
                category="交流",
                is_ai_priority=False,
                author_id=user.id
            )
        ])

        db.session.commit()

    # =========================================================
    # 筆記
    # =========================================================
    if Note.query.count() == 0 and admin and user:
        db.session.add_all([
            Note(
                title="機器學習課堂筆記",
                content=(
                    "今天整理了分類模型、"
                    "訓練流程與評估方法。"
                ),
                owner_id=user.id
            ),
            Note(
                title="系統分析會議摘要",
                content=(
                    "確認登入分流、貼文權限"
                    "與管理後台需求。"
                ),
                owner_id=admin.id
            )
        ])

        db.session.commit()

    # =========================================================
    # 好友關係
    # =========================================================
    if (
        Friendship.query.count() == 0
        and user
        and user2
    ):
        db.session.add(
            Friendship(
                requester_id=user.id,
                addressee_id=user2.id,
                status="accepted"
            )
        )

        db.session.commit()

    # =========================================================
    # 好友私人聊天室
    # =========================================================
    if (
        ChatRoom.query.filter_by(
            room_type="private"
        ).count() == 0
        and user
        and user2
    ):
        private_room = ChatRoom(
            name="好友私聊",
            topic="王小明與陳小美的私人聊天",
            room_type="private",
            require_approval=False,
            created_by=user.id
        )

        db.session.add(private_room)
        db.session.commit()

        db.session.add_all([
            ChatRoomMember(
                room_id=private_room.id,
                user_id=user.id,
                role="owner"
            ),
            ChatRoomMember(
                room_id=private_room.id,
                user_id=user2.id,
                role="member"
            )
        ])

        db.session.commit()

        db.session.add_all([
            ChatMessage(
                room_id=private_room.id,
                sender_id=user.id,
                message_type="text",
                content="嗨，你好！"
            ),
            ChatMessage(
                room_id=private_room.id,
                sender_id=user2.id,
                message_type="text",
                content="你好，我們來討論專題吧。"
            )
        ])

        db.session.commit()

    # =========================================================
    # 範例社團
    # =========================================================
    if Community.query.count() == 0 and admin and user:
        ai_club = Community(
            name="AI 黑客松研究社",
            description="討論人工智慧、程式競賽與專題實作。",
            community_type="club",
            join_mode="approval",
            join_password_hash=None,
            avatar_url=None,
            creator_id=admin.id
        )

        project_group = Community(
            name="校園系統專題群組",
            description="校園 AI 學生資訊交換系統開發討論。",
            community_type="group",
            join_mode="open",
            join_password_hash=None,
            avatar_url=None,
            creator_id=user.id
        )

        db.session.add_all([
            ai_club,
            project_group
        ])

        db.session.commit()

        db.session.add_all([
            CommunityMember(
                community_id=ai_club.id,
                user_id=admin.id,
                role="owner"
            ),
            CommunityMember(
                community_id=project_group.id,
                user_id=user.id,
                role="owner"
            )
        ])

        db.session.commit()


app = create_app()


if __name__ == "__main__":
    socketio.run(
        app,
        host="0.0.0.0",
        port=5000,
        debug=True,
        allow_unsafe_werkzeug=True
    )